let cart = 0;
const count = document.getElementById("cartCount");
const toast = document.getElementById("toast");

document.querySelectorAll(".add").forEach(button => {
  button.addEventListener("click", () => {
    cart++;
    count.textContent = cart;
    count.classList.remove("cart-pop");
    void count.offsetWidth;
    count.classList.add("cart-pop");
    toast.textContent = `${button.dataset.product} added to bag.`;
    toast.classList.add("show");
    setTimeout(() => toast.classList.remove("show"), 1800);
  });
});

document.getElementById("cartButton").addEventListener("click", () => {
  if (cart === 0) {
    toast.textContent = "Your bag is empty.";
  } else {
    toast.textContent = `You have ${cart} item${cart === 1 ? "" : "s"} in your bag.`;
  }
  toast.classList.add("show");
  setTimeout(() => toast.classList.remove("show"), 1800);
});
