// Dristlelet Catalogue
// Edit this file to add, remove, or update products.
// Keep the same fields for each product.

const catalogue = [
  {
    name: "Dristlelet Hoodie",
    price: "£45",
    image: "images/hoodie.jpg",
    description: "Dristlelet signature hoodie."
  },
  {
    name: "Dristlelet Pink Hoodie",
    price: "£45",
    image: "images/pink-hoodie.jpg",
    description: "Pink and purple Dristlelet hoodie."
  },
  {
    name: "Dristlelet Blue Hoodie",
    price: "£45",
    image: "images/blue-hoodie.jpg",
    description: "Blue Dristlelet hoodie."
  }
];
